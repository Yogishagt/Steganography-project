/*name: Yogisha gt
date: 09/10/2024
title: LSB stegnograpy poject.
Aim: Hide the some data to another data */

#include <stdio.h>
#include "encode.h"
#include "decode.h"
#include "types.h"

int main(int argc, char  *argv[]) 
{
    // checking for command line argument count 
    if(argc<4){
        printf("INFO: Error : Insufficient arguments\n");
        printf("INFO: Usage:- For Encodeing -> ./a.out -e  <.bmp file> secret file>\nFor Decoding  -> ./a.out -d <.bmp file> <output file>\n");
        return e_failure;
    }
    else{
        // checking operation type
        if(check_operation_type(argv) == e_encode){
            printf("INFO: ENCODING OPERATION IS SELECTED\n");
            // structure defination
            EncodeInfo encInfo;
            // validating the CLA
            if(read_and_validate_encode_args(argv, &encInfo) == e_success){
                printf("INFO: read and validation for encoding is success\n");
                if(do_encoding(&encInfo) == e_success){
                    printf("INFO: ## Encoding is completed ##\n");
                }
                else{
                    printf("INFO: Error in encoding\n");
                }
            }
            else{
                printf("INFO: Error in reading and validation for encoding\n");
            }
        }
        else if(check_operation_type(argv) == e_decode){
            printf("INFO: ## DECODING OPERATION IS SELECTED\n");
            // structure defination
            DecodeInfo decInfo;
            //  validating the CLA
            if(read_and_validate_decode_args(argv, &decInfo) == e_success){
                printf("INFO: ## Decoding procedure Started ##\n");
                if(do_decoding(&decInfo) == e_success){
                    printf("INFO: ## Decoding is completed Successfully##\n");
                }
                else{
                    printf("INFO: Error in decoding\n");
                }
            }
            else{
                printf("INFO: Error in reading and validation for decoding\n");
            }
        }
        else{
            printf("INFO: Error : Invalid operation type\n");
            printf("INFO: Usage:- For Encodeing -> ./a.out -e  <.bmp file> secret file>\n For Decoding  -> ./a.out -d <.bmp file> <output file>\n");
            return e_failure;
        }
    }
    return 0;
}
                                