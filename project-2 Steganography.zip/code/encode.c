/*name: Yogisha gt
date: 09/10/2024
title: encoding the secret msg */
#include <stdio.h>
#include "encode.h"
#include "types.h"
int byte_size=0;


Status copy_remaining_img_data(FILE *fptr_src, FILE *fptr_dest){
    char ch;
    //  copy the remaining data from source file to destination file
    while((fread(&ch,1,1,fptr_src   )) >0){
        // writing the  data to destination file
        fwrite(&ch,1,1,fptr_dest);  
    }
    return e_success;
}

Status encode_secret_file_data(EncodeInfo *encInfo){
    printf("INFO: Encoding %s file data\n",encInfo-> secret_fname);
    // encode secret file data
   // moving  pointer to the beginning of the file
    fseek(encInfo -> fptr_secret, 0, SEEK_SET);	

    char buffer[encInfo->size_secret_file];
    // read secret file
    fread(buffer,encInfo->size_secret_file,1,encInfo->fptr_secret);

    if(encode_data_to_image(buffer,encInfo->size_secret_file,encInfo) ==  e_success){
        return e_success;
    }
    return e_failure;
}

Status encode_secret_file_size(int file_size, EncodeInfo *encInfo){
    printf("INFO: Encoding %s file size\n",encInfo-> secret_fname);
    //function calling
    if(encode_size_to_lsb(file_size,encInfo) == e_success){
        return e_success;
    }
    return e_failure;
}

Status encode_secret_file_extn(const char *file_extn, EncodeInfo *encInfo){
    printf("INFO: Encoding %s file extension\n",encInfo-> secret_fname);
    // function calling
    if(encode_data_to_image(file_extn,strlen(file_extn),encInfo) ==  e_success){
        return e_success;
    }
    return e_failure;
}

Status encode_secret_file_extn_size(int extn_size, EncodeInfo *encInfo){
    printf("INFO: Encoding %s file extension size\n",encInfo-> secret_fname);
    // function calling
    if(encode_size_to_lsb(extn_size,encInfo) == e_success){
        return e_success;
    }
    return e_failure;
}

Status encode_size_to_lsb(int size, EncodeInfo *encInfo){
    //declaring char array
    char buffer[32];										
    
    //reading 32 bytes from souce bmp file and storing to str
    fread(buffer, 32, 1, encInfo -> fptr_src_image);		

    //storing secret data to LSB
    for(int i = 0; i < 32; i++){
	    buffer[i] = (buffer[i] & 0xFE) | ((size >> (31 - i)) & 1); //((size >> (1 - i)) & 1);					
    }

    //storing 32 bytes of modified data into stego image
    fwrite(buffer, 32, 1, encInfo -> fptr_stego_image);						
    
    return e_success;

    
}

// encode 1 byte data in buffer
Status  encode_byte_to_lsb(char data, char *image_buffer){
     for(int i = 0; i < 8; i++){
        //storing secret data to LSB
	    image_buffer[i] = (image_buffer[i] & 0xFE) | ((data >> (7-i) ) &1);	 // storing data msb in lower addres
	}
    return e_success;
    
}

Status  encode_data_to_image(const char *data, int size, EncodeInfo *encInfo){

    //loop till no. of character times
    for(int i = 0; i < size; i++){

        //reading 8 bytes from source bmp file and storing it to image_data
	    fread(encInfo -> image_data, 8, 1, encInfo -> fptr_src_image);	

        //function call
	    if(encode_byte_to_lsb(data[i], encInfo -> image_data) == e_success){				
            //storing 8 bytes of modified data into stego image
	        fwrite(encInfo -> image_data, 8, 1, encInfo -> fptr_stego_image);		
        }
        else{
            printf("INFO: error encode byte to lsb\n");
            return  e_failure;
        }
    }

    return e_success;

}

Status encode_magic_string(char *magic_string, EncodeInfo *encInfo){
    // moving the  pointer to the 54th position of the file
    fseek(encInfo->fptr_src_image,54,SEEK_SET);
    // function calling
    printf("INFO: Encoding magic string\n");
    if(encode_data_to_image(magic_string, strlen(magic_string), encInfo) ==  e_success){
        return e_success;
    }
    return e_failure;
}


Status check_capacity(EncodeInfo *encInfo){
    // Check if the secret file 
    

    // storing the size of source file
    encInfo->image_capacity=get_image_size_for_bmp(encInfo -> fptr_src_image);
    printf("INFO: Image capacity size is: %u bytes\n", encInfo->image_capacity);
    
    // storing the secret  data size
    encInfo->size_secret_file=get_file_size(encInfo->fptr_secret);
    printf("INFO: Encoding data size is: %ld bytes\n",encInfo->size_secret_file);

    // checking source file as enogh space to encode the secret data
    if(encInfo->image_capacity > (54 + (2 + 4 + 4 + 4 + encInfo->size_secret_file)*8)){ // 54 for header, 2 for magic string, 4 for extn size, 4 for extn, 4 for secret data size
        return e_success;
    }
    return e_failure;
}


uint get_file_size(FILE  *fptr){
    // Get the size of the secret file
    fseek(fptr,0,SEEK_END);
   long int size = ftell(fptr);
    return (size);
}

OperationType check_operation_type(char *argv[]){
    // Check if the operation is encode or decode
    if (strcmp(argv[1], "-e") == 0){
        return  e_encode;
    }
    else if(strcmp(argv[1],"-d")==0){
        return e_decode;
    }
    else{
        return e_unsupported;
    }
}

Status read_and_validate_encode_args(char *argv[], EncodeInfo *encInfo){
     // Check if the number of arguments is correct
    if(strstr(argv[2],".") ==  NULL){
        printf("INFO: Usage:- For Encodeing -> ./a.out -e  <.bmp file> secret file>\n");
        return  e_failure;
    }
    if(!strcmp(strstr(argv[2],"."), ".bmp")){
        printf("INFO: argv[2] is having .bmp extension\n");
        encInfo-> src_image_fname =argv[2];
        if((strstr(argv[3],".")) == NULL){
            printf("INFO: Usage:- For Encodeing -> ./a.out -e  <.bmp file> secret file>\n");
            return  e_failure;
        }
        // Check if the secret file is provided
        if((!strcmp(strstr(argv[3],"."), ".txt") ) || (!strcmp(strstr(argv[3],"."), ".c")) ||  (!strcmp(strstr(argv[3],"."), ".sh"))){ 
            printf("INFO: argv[3] is having  .txt or .c or .sh extension\n");
            encInfo->secret_fname=argv[3];
            encInfo->extn_secret_file=strstr(argv[3],".");
            // Check if the output file is provided
            if(argv[4]!=NULL){
                if(strstr(argv[4],".") == NULL){
                    printf("INFO: Usage:- For Encodeing -> ./a.out -e  <.bmp file> secret file>\n");
                    return   e_failure;
                }
                if((!strcmp(strstr(argv[4],"."), ".bmp"))){
                    printf("INFO: argv[4] is having .bmp extension\n");
                    encInfo-> stego_image_fname=argv[4];
                    return  e_success;
                }
                else{
                    printf("INFO: Usage:- For Encodeing -> ./a.out -e  <.bmp file> secret file>\n");
                    printf("INFO: argument  4 is not having .bmp extension\n");
                    return e_failure;
                }
            }
            else{
                // creating default  output file name
                encInfo -> stego_image_fname="stego.bmp";
                return e_success;
            }

        }
        else{
            printf("INFO: Usage:- For Encodeing -> ./a.out -e  <.bmp file> secret file>\n");
            printf("INFO: argument 3 is not having  .txt or .c or .sh extension\n");
            return e_failure;
        }
    }
    else{
        printf("INFO: Usage:- For Encodeing -> ./a.out -e  <.bmp file> secret file>\n");
        printf("INFO: argument 2 is not having .bmp extension\n");
        return  e_failure;
    }
}


Status copy_bmp_header(FILE *fptr_src_image, FILE *fptr_dest_image){
    // Copy the BMP header from the source image to the destination image
    printf("INFO: Copying image header\n");
    fseek(fptr_src_image,0,SEEK_SET); // to set  the file pointer to the beginning of the file
    char file_header[54];
    // Read the BMP header from the source image
    fread(file_header,sizeof(char),54,fptr_src_image);
    // Copy the BMP header to the destination image
    fwrite(file_header,sizeof(char),54,fptr_dest_image);
    byte_size=ftell(fptr_dest_image);

    printf("INFO: Copied successfully\n");
    return e_success;
}

/* Function Definitions */

/* Get image size
 * Input: Image file ptr
 * Output: width * height * bytes per pixel (3 in our case)
 * Description: In BMP Image, width is stored in offset 18,
 * and height after that. size is 4 bytes
 */

// uint get_image_size_for_bmp(EncodeInfo *encInfo)
uint get_image_size_for_bmp(FILE *fptr_image){
    uint width, height;
    // Seek to 18th byte

    fseek(fptr_image, 18, SEEK_SET);
    // Read the width (an int)
    fread(&width, sizeof(int), 1,fptr_image);
    printf("INFO: width = %u\n", width);

    // Read the height (an int)
    fread(&height, sizeof(int), 1,fptr_image);
    printf("INFO: height = %u\n", height);
    // Return image capacity
    return width * height * 3; //3 is for converting pixel to bytes
}

/* 
 * Get File pointers for i/p and o/p files
 * Inputs: Src Image file, Secret file and
 * Stego Image file
 * Output: FILE pointer for above files
 * Return Value: e_success or e_failure, on file errors
 */
Status open_files(EncodeInfo *encInfo){
    // Src Image file
    encInfo->fptr_src_image = fopen(encInfo->src_image_fname, "r");
    // Do Error handling
    if (encInfo->fptr_src_image == NULL){
    	printf("INFO: Error in opening source file!\n") ;  // print error message
    	return e_failure;
    }

    // Secret file
    encInfo->fptr_secret = fopen(encInfo->secret_fname, "r");
    // Do Error handling
    if (encInfo->fptr_secret == NULL){
    	printf("INFO: Error in opening decret file!\n");
    	return e_failure;
    }

    // Stego Image file
    encInfo->fptr_stego_image = fopen(encInfo->stego_image_fname, "w");
    // Do Error handling
    if (encInfo->fptr_stego_image == NULL){
    	printf("INFO:Error in opening stego file!\n");
    	return e_failure;
    }

    // No failure return e_success
    return e_success;
}

// do encoding function defination where all the function is called
Status do_encoding(EncodeInfo *encInfo){
    if(open_files(encInfo) == e_success){
        printf("INFO: Files opened successfully\n");

    if(copy_bmp_header(encInfo-> fptr_src_image, encInfo-> fptr_stego_image) == e_success){ 
        printf("INFO: Encoded successfully\n");

    if(check_capacity(encInfo) == e_success){
        printf("INFO: Encoded successfully\n");
        
        if(encode_magic_string(MAGIC_STRING,encInfo) == e_success){
            printf("INFO: Encoded successfully\n");
            strcpy(encInfo -> extn_secret_file, strstr(encInfo -> secret_fname, "."));

            if(encode_secret_file_extn_size(strlen(encInfo->extn_secret_file),encInfo) == e_success){
                printf("INFO: Encoded successfully\n");
                
                if(encode_secret_file_extn(encInfo->extn_secret_file,encInfo) ==  e_success){
                    printf("INFO: Encoded successfully\n");

                    if(encode_secret_file_size(encInfo->size_secret_file,encInfo)==  e_success){
                        printf("INFO: Encoded successfully\n");

                        if(encode_secret_file_data(encInfo) == e_success){
                            printf("INFO: Encoded successfully\n");

                            if(copy_remaining_img_data(encInfo->fptr_src_image, encInfo->fptr_stego_image) == 0){
                                printf("INFO: Encoded successfully\n");
                                // closeing the  files
                                fclose(encInfo->fptr_src_image);
                                fclose(encInfo->fptr_stego_image);
                                fclose(encInfo->fptr_secret);
                                return e_success;
                            }
                            else{
                                printf("INFO: Error in copying remaining image data\n");
                                return e_failure;
                            }
                        }
                        else{
                            printf("INFO: Error in encoding secret file size\n");
                            return e_failure;
                        }
                    }
                    else{
                        printf("INFO: Error in encoding secret file extension size\n");
                        return  e_failure;
                    }
                }
                else{
                    printf("INFO: Error in encoding secret file data\n");
                    return  e_failure;
                }
            }
            else{
                printf("INFO: Error in encoding secret file extension\n");
                return  e_failure;
            }
        }
        else{
            printf("INFO: Error in encoding magic string\n");
            return  e_failure;
        }
    }   
    else{
        printf("INFO: Error in checking capacity\n");
        return  e_failure;
    }
    }
    else{
        printf("INFO: Error in opening stego image file\n");
        return  e_failure;
    }
    }
    else{
        printf("INFO: Error in opening file\n");
        return  e_failure;
    }
    
}