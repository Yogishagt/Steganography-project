/*name: Yogisha gt
date: 09/10/2024
title: decoding the secret msg */
#include <stdio.h>
#include "decode.h"
#include "types.h"
#include <string.h>
#include "common.h"



Status read_and_validate_decode_args(char *argv[], DecodeInfo *decInfo){
    // checking  if arguments is having .bmp
    if(strstr(argv[2],".") == NULL){
        printf("INFO: Usage:- For Decoding  -> ./a.out -d <.bmp file> <output file>\n");
        return e_failure;
    }
    if(!(strcmp(strstr(argv[2],"."),".bmp"))){
        printf("INFO: argv[2] is having .bmp extension\n");
        decInfo->stego_image_fname=argv[2];
        // checking if argument haveing .txt or .sh or .c
        decInfo -> decoded_file_fname = strtok(argv[3],".");
        return e_success;
    }
    else{
        printf("INFO: Usage:- For Decoding  -> ./a.out -d <.bmp file> <output file>\n");
        printf("INFO: argv[2] is not having .bmp extension\n");
        return e_failure;
    }
}

Status open_file(DecodeInfo *decInfo){

    // open  the stego image
    decInfo->fptr_stego_image = fopen(decInfo->stego_image_fname,"r");
    // error  checking
    if(decInfo->fptr_stego_image == NULL){
        printf("INFO: Error in opening stego image file\n");
        return e_failure;
    }

    // No failure return e_success
    return e_success;
}

Status decode_magic_string(FILE *fptr, char *magic_string, DecodeInfo *decInfo){
    //moving FILE pointer to 54th position from beginning
    fseek(fptr, 54, SEEK_SET);		
    // size of magic string 						
    int size = strlen(magic_string);

    for(int i = 0; i < size; i++){
        //reading 8 bytes from Stego image
	    fread(decInfo -> image_data, 8, 1, decInfo -> fptr_stego_image);		
        //decoding 1 byte
	    decode_byte_from_lsb(decInfo -> image_data, decInfo);				
        //storing the decoded byte in magic_str
	    decInfo -> magic_str[i] = decInfo -> one_byte;		
        //adding null character at the end			
	    decInfo -> magic_str[i+1] = '\0';						
    }
    // reading a magic string from user 
    char magic_strings[10];
    printf("INFO: Enter the magic string: ");
    scanf("%s", magic_strings);
    //validating magic string 
    if(strcmp(magic_strings, decInfo -> magic_str) == 0){
        printf("INFO: User Entered Magic String and Decoded Magic String both are Matched\n");
        return e_success;
    }				
    else{
        printf("INFO: User  Entered Magic String and Decoded Magic String both are Not Matched\n");
        return  e_failure;
    }
}


Status decode_extn_size(DecodeInfo *decInfo){
    printf("INFO: Decoding Output File Extension Size\n");
    //function call
    decode_size_from_lsb(decInfo);				

    //storing extension size in extn_size
    decInfo -> extn_size = decInfo -> int_data;			

    return e_success;
}


Status decode_secret_file_extn(DecodeInfo *decInfo){
    printf("INFO: Decoding output  file extension\n");
    int size = decInfo -> extn_size;
    
    for(int i = 0; i < size; i++)
    {
	fread(decInfo -> image_data, 8, 1, decInfo -> fptr_stego_image);			//reading 8 bytes from Stego image

	decode_byte_from_lsb(decInfo -> image_data, decInfo);					//decoding 1 byte

	decInfo -> extn_decoded_file[i] = decInfo -> one_byte;					//storing the decoded byte in extn_decoded_file
	decInfo -> extn_decoded_file[i+1] = '\0';						//adding null character at the end

    }

    decInfo->decoded_file_fname = strcat(decInfo->decoded_file_fname,decInfo -> extn_decoded_file);
    printf("INFO: Created output file %s is Done\n",decInfo->decoded_file_fname);

    // opening the  decoded file (output file)
    decInfo->fptr_decoded_file=fopen(decInfo->decoded_file_fname,"w");
    // error handling
    if(decInfo->fptr_decoded_file == NULL){
        printf("INFO: Error in opening output file\n");
        return e_failure;
    }
    printf("INFO: Opened %s\n",decInfo->decoded_file_fname);
    return e_success;
   
} 



Status decode_secret_file_size(DecodeInfo *decInfo){
    printf("INFO: Decoding file size\n");
    //function call
    decode_size_from_lsb(decInfo);						

    //storing size of the file in size_decoded_file
    decInfo -> size_decoded_file = decInfo -> int_data;	
    // printf("size is %d\n",decInfo-> int_data)			;

    return e_success;
}



Status decode_secret_file_data(DecodeInfo *decInfo){
    printf("INFO: Decoding file data\n");
    //function call
    //  printf("size is %ld\n",decInfo -> size_decoded_file);
    decode_data_from_image(decInfo -> size_decoded_file, decInfo);	
    // decode_data_from_image(decInfo);		

    return e_success;
}

Status decode_data_from_image(int size, DecodeInfo *decInfo){
    for(int i = 0; i < size; i++){
        //reading 8 bytes from stego bmp file and storing it to image_data
	    fread(decInfo -> image_data, 8, 1, decInfo -> fptr_stego_image);		
        //function call
	    decode_byte_from_lsb(decInfo -> image_data, decInfo);				
	    fwrite(&decInfo -> one_byte, 1, 1, decInfo -> fptr_decoded_file);		
    }
    return e_success;
}



Status decode_byte_from_lsb(char *image_buffer, DecodeInfo *decInfo){
    char data = 0x00;
    for( int i = 0; i < 8; i++){
	    data = data << 1;
        //logic to decode
	    data = data | image_buffer[i] & 0x01;			
    }
    //storing 1 byte of decoded character data to one_byte
    decInfo -> one_byte = data;					
	return e_success;
}


Status decode_size_from_lsb(DecodeInfo *decInfo)
{
    //declaring char array
    char str[32];										

    int int_data = 0x00;

    // reading  32 bytes from stego bmp file and storing it to str
    fread(str, 32, 1, decInfo -> fptr_stego_image);						

    for(int i = 0; i < 32; i++)
    {
        //logic to decode
	    int_data = int_data << 1;
	    int_data = int_data | str[i] & 0x01;							
    }

    //storing 4 bytes of decoded integer data into int_data
    decInfo -> int_data = int_data;								
	return e_success;
}



// do decoding function defination where all the function is called
Status do_decoding(DecodeInfo *decInfo){
    if(open_file(decInfo) ==  e_success){
        printf("Files opened successfully\n");
        
        if(decode_magic_string(decInfo -> fptr_stego_image,MAGIC_STRING, decInfo) == e_success){
            printf("INFO: Decoding Successfully\n");

            if(decode_extn_size(decInfo) ==  e_success){
                printf("INFO: Decoding Successfully\n");

                if(decode_secret_file_extn(decInfo) ==   e_success){
                    printf("INFO: Decoding Successfully\n");

                    if(decode_secret_file_size(decInfo) == e_success){
                        printf("INFO: Decoding Successfully\n");

                        if(decode_secret_file_data(decInfo) == e_success){
                           printf("INFO: Decoding Successfully\n");

                           // closeing  files
                           fclose(decInfo -> fptr_stego_image);
                           fclose(decInfo ->  fptr_decoded_file);
                           return e_success;
                        }
                        else{
                            printf("INFO: Error in decoding data\n");
                            return e_failure;
                        }
                    }    
                    else{
                        printf("INFO: Error in decoding file size\n");
                        return e_failure;
                    }
                }
                else{
                     printf("INFO: Error in decoding output file extension\n");
                     return e_failure;
                }
            }
            else{
                printf("INFO: Error in decoding output file extension size\n");
                return e_failure;
            }
        }
        else{
            printf("INFO: Error in decoding magic string\n");
            return e_failure;
        }
    }
    else{
        printf("INFO: Error in opening files\n");
        return e_failure;
    }
}
